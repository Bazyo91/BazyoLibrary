/**
 * Written by BaZyO, all rights reserved
 * */
package test;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import bazyo.ui.button.ButtonCreation;
import bazyo.ui.frame.FrameCreation;
import bazyo.ui.frame.LoginformCreation;
import bazyo.ui.optionpane.SelectDatabaseColumn;

/**
 * @author BaZyO
 *
 */
public class Test {
	FrameCreation f = new FrameCreation();
	ButtonCreation b = new ButtonCreation();
	LoginformCreation login = new LoginformCreation();
	SelectDatabaseColumn select = new SelectDatabaseColumn();
	
	/**
	 * 
	 */
	public Test() {
		select.selectOneData();
		login.loginForm();
		
//		b.connectionButton("Testing", 100, 100, 100, 30, Color.BLACK, "Arial", Font.BOLD, 14);
//		
//		f.mainFrame("Test", 500, 300, 700, 500, false, Color.DARK_GRAY);
//		f.add(b);
	}
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new Test();
	}
}
